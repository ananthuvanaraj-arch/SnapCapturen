package com.example.snapcapture

import android.content.ContentValues
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import android.graphics.BitmapFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Ink = Color(0xFF211B32)
private val Purple = Color(0xFF6960EC)
private val Lavender = Color(0xFFF4F1FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SnapCaptureApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SnapCaptureApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var savedMessage by remember { mutableStateOf("Import an edited photo from Prequel to get started.") }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            selectedUri = uri
            savedMessage = "Photo ready. You can save a copy to your gallery."
        }
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Purple,
            background = Color.White,
            surface = Color.White
        )
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("SnapCapture", fontWeight = FontWeight.Bold, color = Ink)
                            Text("Your personal edit library", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                        }
                    }
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                Box(
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp))
                        .background(Lavender).padding(22.dp),
                    contentAlignment = Alignment.Center
                ) {
                    if (selectedUri == null) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Icon(Icons.Default.PhotoCamera, null, tint = Purple, modifier = Modifier.size(48.dp))
                            Text("Capture Studio", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Ink)
                            Text("Bring your Prequel edits together in one place.", color = Color.DarkGray)
                            Button(onClick = { picker.launch("image/*") }) {
                                Icon(Icons.Default.AddPhotoAlternate, null)
                                Spacer(Modifier.width(8.dp))
                                Text("Import a photo")
                            }
                        }
                    } else {
                        val bitmap = remember(selectedUri) {
                            context.contentResolver.openInputStream(selectedUri!!)?.use {
                                BitmapFactory.decodeStream(it)
                            }
                        }
                        if (bitmap != null) {
                            Image(
                                bitmap = bitmap.asImageBitmap(),
                                contentDescription = "Selected edit",
                                modifier = Modifier.fillMaxWidth().heightIn(max = 420.dp).clip(RoundedCornerShape(18.dp)),
                                contentScale = ContentScale.Fit
                            )
                        }
                    }
                }

                Button(
                    onClick = { picker.launch("image/*") },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.AddPhotoAlternate, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Import from Prequel")
                }

                OutlinedButton(
                    onClick = {
                        val uri = selectedUri
                        if (uri == null) {
                            Toast.makeText(context, "Import a photo first", Toast.LENGTH_SHORT).show()
                        } else {
                            scope.launch {
                                val result = withContext(Dispatchers.IO) { saveCopyToGallery(context, uri) }
                                Toast.makeText(
                                    context,
                                    if (result) "Saved to Pictures/SnapCapture" else "Could not save this image",
                                    Toast.LENGTH_LONG
                                ).show()
                                savedMessage = if (result) "Saved a copy to your gallery." else "Save failed. Please try another image."
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = selectedUri != null
                ) {
                    Icon(Icons.Default.Download, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Save copy to gallery")
                }

                Text("How it works", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Ink)
                Text(
                    "In Prequel, use its own Export or Save option, then open SnapCapture and import the exported image. This keeps the original image quality and respects Android's protected-screen rules.",
                    color = Color.DarkGray,
                    style = MaterialTheme.typography.bodyMedium
                )
                Text(savedMessage, color = Purple, style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.weight(1f))
                Text("SnapCapture • Version 1.0", color = Color.Gray, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

private fun saveCopyToGallery(context: android.content.Context, source: Uri): Boolean {
    return try {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "SnapCapture_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/SnapCapture")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val destination = context.contentResolver.insert(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values
        ) ?: return false

        context.contentResolver.openInputStream(source).use { input ->
            context.contentResolver.openOutputStream(destination).use { output ->
                if (input == null || output == null) throw IllegalStateException("Unable to open image")
                input.copyTo(output)
            }
        }
        values.clear()
        values.put(MediaStore.Images.Media.IS_PENDING, 0)
        context.contentResolver.update(destination, values, null, null)
        true
    } catch (_: Exception) {
        false
    }
}
