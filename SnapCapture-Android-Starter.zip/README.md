# SnapCapture (Android / Kotlin)

A small native Android starter app for collecting your own Prequel exports.

## Open
1. Install Android Studio (current stable).
2. Choose **Open** and select this project folder.
3. Allow Gradle sync to finish.
4. Connect an Android phone with USB debugging enabled, or create an emulator.
5. Press Run.

## Current MVP
- Imports an image using Android's system photo picker.
- Previews the selected image.
- Saves a copy to `Pictures/SnapCapture`.

## Prequel workflow
Export/save your own edit in Prequel, then import that exported image here. If Prequel marks its screen as secure, Android intentionally prevents third-party screen capture; this starter app does not attempt to bypass that restriction.

## Next development step
A user-consented MediaProjection capture mode can be added for screens/apps that permit capture. Protected Prequel screens will still not be capturable through that API.
